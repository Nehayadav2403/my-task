// import logo from './logo.svg';
import "./App.css";
import React from "react";
// import Todo from "./component/todolist";
// import Router from "./component/Router";
import { BrowserRouter } from "react-router-dom";
import AllRouters from "./component/Router/AllRouters";


function App() {
  return (
    <div>
    <BrowserRouter>
   {/* <NavLink to={"/todo"}>Todo</NavLink>
    <NavLink to={"/banner"}>Banner</NavLink>
    <NavLink to={"/light"}>Light</NavLink>
  <NavLink to={"/counter"}>Counter</NavLink>
    <Router/>*/}
    <AllRouters/>
    
    </BrowserRouter>
    </div>
  );
}

// import Counter from './component/counter';

// class App extends React.Component
// {
//   constructor(props)
//   {
//     super(props)
//     this.state = {
//       name:"neha",
//       reName: ()=>{
//         this.setState({name:"neha yadav"})
//       }

//     }
//   }

//   render()
//     {
//       return <div>
//       <p>{this.state.name}</p> <button onClick={this.state.reName}>Rename</button>

//        </div>

//   }

// }
// export default App;

// class App extends React.Component
//{
//     constructor(props)
//     {
//         super(props)
//         this.state = {

//         }
//     }
//}

//  render ()
// {
//     return (
//         <div>
//           <>
//             <h1>Add to List</h1>
//             <input type='text'></input>
//             <button type='button'>Add</button>
//             <table>
//   <tr>
//     <th>To do list</th>
//     <th>Completed</th>
//     <th>All</th>
//   </tr>
//   <tr>
//     <td></td>
//     <td></td>
//     <td></td>
//   </tr>
//   <tr>
//     <td></td>
//     <td></td>
//     <td></td>
//   </tr>
// </table>
// </>//
//         </div>
//     )
// }
export default App;
