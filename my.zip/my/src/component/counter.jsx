// import logo from './logo.svg';
import React from 'react';

class Counter extends React.Component
{
  constructor(props)
  {
    super(props)
    this.state = {
        count:0,
        buttondisabled:false,
      
  
      }
  }
    increase = ()=>{
   
      this.setState({count:this.state.count +1,buttondisabled:false})
      }
    
  
    decrease = ()=>{
      if(this.state.count === 0)
      {
        this.setState({buttondisabled:true})
      }
      else
      {
        this.setState({count:this.state.count -1,buttondisabled:false})
      }
    
    }



    render()
      {
        return <div className='App'>
             <h1>{this.state.count}</h1>
       
       <button type='button' onClick={this.increase}>+</button>
        <button type='button' disabled={this.state.buttondisabled} onClick={this.decrease}>-</button>
       </div>
      }
      
    
  
  

}
export default Counter;