import React from "react";



class ChangeColor extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            color:"",

            color:()=>{
                this.setState({color:"red"})
            }
        }
        
   }


    render()
    {
        return(
            <div className="button"  >
            <button className="red" onClick={()=>this.setState({color:"red"})} >Red</button>
            <button className="blue" onClick={()=>this.setState({color:"blue"})}>Blue</button>
            <button className="green" onClick={()=>this.setState({color:"green"})}>Green</button>
            <button className="yellow" onClick={()=>this.setState({color:"yellow"})}>Yellow</button>
            <button className="orange"  onClick={()=>this.setState({color:"orange"})}>Orange</button>
            

          
             <div className="text" style={{background:"#f0f0f0f"}}>
            <h2 style={{color:this.state.color}}> This is my text</h2>
            </div>
            </div>
        )
    }
}
export default ChangeColor;