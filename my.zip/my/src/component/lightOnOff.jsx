import React from "react";

class Light extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
         img:"light on.jpg"
        }
    }

    render()
    {
        return(
            <div>
           <img src={this.state.img} alt="no img"/>
          <button onClick={()=>this.setState({img:"light on.jpg"})} className = 'lightOn'>On</button>
          <button onClick={()=>this.setState({img:"light off.jpg"})} className = 'lightOff' >Off</button>


            </div>
        )
    }
}
export default Light;