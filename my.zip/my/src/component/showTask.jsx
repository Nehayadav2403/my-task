import React from "react";


class Show extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state ={
         message:"hello"
        }
    }
    render()
    {
        return(
            <div className="container">
            <h1 style={this.props.color}>{this.state.message}</h1>
            </div>
        )
    }
}
export default Show;