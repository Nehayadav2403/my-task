import React from "react";

class User extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
        inputText:"",
        todoList:[],
        addToList:()=>{
          this.setState({todoList:[...this.state.todoList,{name:this.state.inputText,check:"false"}],inputText:""})
        },
        complete:[],
        completed:(index)=>{
          this.setState({complete:[...this.state.complete,...this.state.todoList.splice(index,1)],inputText:""})

        },
        remove:(index)=>{
          this.state({remove:[this.state.todoList,this.state.todoList.splice(index,1)]})

        },

        onChecked:(e,index)=>{
            let newToDo = this.state.todoList;
            newToDo[index].check = e.target.checked;
            this.setState({todoList:newToDo});
        },

        SubmitAll:()=>{

            let find = [];
            let notFind = [];
        
            this.state.todoList.map((user,index)=>{
                if(user.check)
                {
                  find=[...find,user];
                }
                else
                {
                    notFind=[...notFind,user];
                }
            });

            this.setState({
                complete:[...this.state.complete,...find],
                todoList : notFind,
            })
            
        }
              
    
      }
    }
    


    render ()
     {
                  const {inputText,todoList,complete}= this.state
                  console.log("addToList=>",todoList);
                  return (
                    
                <div className='container'>

           
                  <h1>Add to List</h1>
                  <input type='text' placeholder="enter task" value={inputText} 
                  onChange = {(e)=>this.setState ({inputText:e.target.value})}></input>

                  <button onClick={this.state.addToList}>Add</button>


               { !!todoList.length &&  ( 
               <div>
                <h1>To Do List</h1>
                {todoList.map((list,index)=>

                  
                  <h1 key={index}><input type={"checkbox"}
                   onChange = {(e)=>{this.state.onChecked(e,index)}}
                  checked = {list.checked} />
                  {index+1}-{list.name}
                  <button type='submit' onClick={this.state.completed}>Submit</button>
                 
                  </h1>
                  
                
                  )
                }
                 <button type='submit' onClick={this.state.SubmitAll}>Submit All</button>
                 <h1>Completed</h1>
               </div>
               )}
            
            <div>
                
                {complete.map((list,index)=>
                   <h1 key={index}>
                    {index+1}-{list.name}</h1>

                )}
               </div>
                 

            </div>
   
        );
       }       
    }


export default User;