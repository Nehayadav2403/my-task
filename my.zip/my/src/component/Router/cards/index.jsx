import { Container } from "@mui/system";
import React, { useEffect, useState } from "react";
import cardData from "./cardData.json";
import MediaCard from "../MediaCard";

const Cards =()=>
{
    const [cardData,setCardData] =useState([]);
    const getData =()=>{
        fetch(`https://jsonplaceholder.typicode.com/posts`)
        .then(response => response.json())
        .then(json =>{
            setCardData(json);
        })
    }
    useEffect(()=>{
        getData();
    });
    return(
            <div>
            
            <Container 
                style={{
                    display:"flex",
                    justifyContent:"space-between",
                    flexWrap:"wrap",
                    margin:"10px",
                  
                 
                }}   
              >
              {cardData.map((data,index)=>{
                 
                 const {title,subTitle}= data;
                 return <MediaCard title={title}  id={index+1} key={index}/>;
                 
                 
              })}
            </Container>
                
            </div>
         
    )
}
export default Cards