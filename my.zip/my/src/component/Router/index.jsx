import React from "react";
import {Route,Routes } from "react-router-dom";
import Counter from "../counter";
import Light from "../lightOnOff";
import Banner from "../Login/Banner";
import Todo from "../todolist";



const Router = () => {
  return (
    
    
    <Routes>
      <Route exact path="/todo" element={<Todo />} />
      <Route exact path="/banner" element={<Banner />} />
      <Route exact path="/light" element={<Light />} />
      <Route path="/counter" element={<Counter />} />
    </Routes>
 
  )
};
export default Router;
