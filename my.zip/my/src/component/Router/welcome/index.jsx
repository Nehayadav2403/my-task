import { Button, Typography } from "@mui/material";
import React from "react";
import { NavLink } from "react-router-dom";
import Navbar from "../Navbar";



const Welcome = () => {
  return (
    <div>
    <Navbar/>
    <div>
     <Typography variant="h2">
       Welcome to the page.
     </Typography>
     <NavLink to={"/home"}>
     <Button variant="outlined" color="info">Get Started </Button>
     </NavLink>
    </div>
    </div>
  );
};
export default Welcome;
