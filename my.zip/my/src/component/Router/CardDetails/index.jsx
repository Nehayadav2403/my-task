import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import cardData from "../cards/cardData.json";
import DetailsCard from "../DetailsCard"

const CardDetail =()=>
{

    const {id} = useParams();
    const [CardDetail,setCardDetail]= useState(null);
    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        .then(response => response.json())
        .then(json =>{
            setCardDetail(json);
        })
       
    },[CardDetail]);
    return CardDetail ? <DetailsCard CardDetail = {CardDetail}/>:<>"NoData"</>;
};
export default CardDetail