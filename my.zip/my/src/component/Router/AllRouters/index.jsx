import React from "react";
import {Routes,Route } from "react-router-dom";
import CardDetail from "../CardDetails";
import Home from "../home";

import Welcome from "../welcome";

const AllRouters =()=>
{
    return(

        <Routes>

         <Route path="/" element = {<Welcome/>}/>
         <Route path="/home" element = {<Home/>}/>
         <Route path="/card/:id" element = {<CardDetail/>}/>
         <Route path="*" element = {<h1>No Data Found</h1>}/>
        </Routes>
    )
}
export default AllRouters