import { Component } from "react";
import Show from "./showTask";

class MultiBox extends Component
{
    constructor(props)
    {
        super(props)
        this.state = {
          color:"",
          
          addColor : (background)=>{
            this.setState({color:background})
            console.log(this.state.color);
        }
           }

           

         

       
    }
    render()
    {
        return (
            <div style={{width:"207px",height:"208px",display:"flex",flexWrap:"wrap"}}>

            <div style={{width:"50px",height:"50px",border:"1px solid",background:"red"}} onClick={()=>this.setState.color({color:"red"})} ></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"green"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"yellow"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"black"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"blue"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"orange"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"yellow"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"purple"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"black"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"red"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"green"}}></div>
            <div style={{width:"50px",height:"50px",border:"1px solid",background:"blue"}}></div>
            
            
            
            </div>
            
            
           
          
        )
    }
}
export default MultiBox;