import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export default class Banner extends Component {
  render() {
    const settings = {
      dots: true,
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,
      speed: 2000,
      autoplaySpeed: 2000,
      cssEase: "linear"
    };
    return (
      <div>
        
        <Slider {...settings}>
          <div className="img1">
                 <img src="1.jpg" style={{width:"300px",height:"300px"}}/ >
          </div>

          <div className="img2">
                 <img src="2.jpg" style={{width:"300px",height:"300px"}}/>
          </div>

          <div className="img3">
                  <img src="3.jpg" style={{width:"300px",height:"300px"}}/>
          </div>

          <div className="img4">
                  <img src="4.jpg" style={{width:"300px",height:"300px"}}/>
          </div>

          <div className="img5">
                 <img src="5.jpg" style={{width:"300px",height:"300px"}}/>
          </div>

          <div className="img6">
                <img src="6.jpg" style={{width:"300px",height:"300px"}}/>
          </div>
        </Slider>
      </div>
    );
  }
}