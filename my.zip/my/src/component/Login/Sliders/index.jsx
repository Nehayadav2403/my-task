import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "red" }}
        onClick={onClick}
      />
    );
  }
  
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "green" }}
        onClick={onClick}
      />
    );
  }
  
  export default class SimpleSlider extends Component {
    render() {
      const settings = {
        dots: true,
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />
      };
    return (
      <div >
        
        <Slider {...settings}>
        
          <div className="img-a">
                <img src="a.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-b">
                <img src="b.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-c">
                <img src="c.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-d">
                <img src="d.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-e">
                 <img src="e.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-f">
                  <img src="f.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-g">
                   <img src="g.jpg" style={{width:"200px",height:"200px"}}/>
          </div>

          <div className="img-h">
                    <img src="h.jpg" style={{width:"200px",height:"200px"}}/>
          </div>
          
        </Slider>
      </div>
    );
  }
}