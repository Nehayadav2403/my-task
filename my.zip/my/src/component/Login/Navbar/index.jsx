import React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import LoginIcon from "@mui/icons-material/Login";
import { Alert, Modal} from "@mui/material"

class Navbar extends React.Component {
  state = {
    openModal: false,
    showAlert:false,
  };

  onClickButton = (e) => {
    e.preventDefault();
    this.setState({ openModal: true });
  };

  onCloseModal = () => {
    this.setState({ openModal: false });
  };
showMyAlert=()=>{
  this.setState({showAlert:true})
  setTimeout(()=>{
    this.setState({showAlert:false})
  },3000)
};
  render() {
    return (
      <div>
      <button onClick={()=>this.showMyAlert()}>show</button>
     {this.state.showAlert&& <Alert severity="error">Email and Passwords are incorrect!</Alert>}
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static">
          <Toolbar>
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              aria-label="menu"
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              Login
            </Typography>
            <Button color="inherit"></Button>
            <LoginIcon></LoginIcon>
            <div>
              <Button variant="contained" onClick={this.onClickButton}>
                Guest
              </Button>
              <Modal
                open={this.state.openModal}
                onClose={this.onCloseModal}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
              >
                <Box sx={"style"}>
                  <Typography
                    id="modal-modal-title"
                    variant="h6"
                    component="h2"
                  >
                   Login Page
                  </Typography>
                  <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                  <div className="form-floating mb-3">
                  <input
                         type="email"
                         class="form-control"
                         id="floatingInput"
                         placeholder="name@gmail.com"
                         />
                         <label for="floatingInput">E-mail:</label>
                         </div>
                         <div className="form-floating">
                         <input
                             type="password"
                             class="form-control"
                             id="floatingPassword"
                             placeholder="password"
                             />

                             <label for="floatingPassword">password:</label>
                             <Button
                             variant="outlined"
                             style={{
                                        background:"black",
                                        color:"whitesmoke",
                                        marginRight:"20rem",
                                        marginTop:"1rem",
                             }}
                         >
                          Login
                         </Button>
                         </div>
                   
                  </Typography>
                </Box>
              </Modal>
            </div>
             
          </Toolbar>
        </AppBar>
      </Box>
      </div>
    );
  }
}
export default Navbar;
