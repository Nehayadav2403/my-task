import React from "react";
import Banner from "./Banner";
import Navbar from "./Navbar";
import SimpleSlider from "./Sliders";


class Login extends React.Component
{
    render()
    {
        return(
            <div>
            <Navbar/>
            <Banner/>
            <SimpleSlider />
            </div>
        )
    }
}
export default Login;