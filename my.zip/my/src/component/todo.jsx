// import logo from './logo.svg';
import React from 'react';
// import './App.css';
// import 'bootstrap-4.6.1-dist\css\bootstrap.min.css'
// import 'bootstrap-4.6.1-dist\js\bootstrap.min.js'

class Todo extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
        inputText:"",
        todoList:[],
        addToList:()=>{
          this.setState({todoList:[...this.state.todoList,this.state.inputText],inputText:""})
        },
        complete:[],
        completed:(index)=>{
          this.setState({complete:[...this.state.complete,...this.state.todoList.splice(index,1)],inputText:""})

        },
        remove:(index)=>{
          this.state({remove:[this.state.todoList,this.state.todoList.splice(index,1)]})

        }
    
      }
    
      
    }
  
    


    render ()
     {
                  const {inputText,todoList,complete}= this.state
                  console.log("addToList=>",todoList);
                  return (
                    
                <div className='container'>

           
                  <h1>Add to List</h1>
                  <input type='text' value={inputText} onChange = {(e)=>this.setState ({inputText:e.target.value})}></input>

                  <button onClick={this.state.addToList}>Add</button>


               { !!todoList.length &&  ( 
               <div>
                <h1>To Do List</h1>
                {todoList.map((list,index)=>

                  
                  <h1 key={index}><input type={"checkbox"} />{index+1}-{list}
                  <button type='submit' onClick={this.state.completed}>Submit</button>
                  </h1>
                  
                
                  )
                }
                
                <h1>Completed</h1>
               </div>
               )}
            
            <div>
                
                {complete.map((list,index)=>
                   <h1 key={index}>
                    {index+1}-{list}</h1>

                )}
               </div>
                 

            </div>
   
        );
       }       
    
}

export default Todo;