import React from "react";

class ColorBox extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            
        }
    }
}