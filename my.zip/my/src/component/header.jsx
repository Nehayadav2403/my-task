const Header = ()=>{
    return <div>Header Page</div> 
    

}
export default Header;