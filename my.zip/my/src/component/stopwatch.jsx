import React from "react";

class StopWatch extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state ={
            counter :0,
            start :"" ,
            reset:0,
            hours:0,
            minute:0,
            second:0,

            startTimer : ()=>{
               
                let x = setInterval(()=>{
                    this.setState({counter:this.state.counter+1})
                
                if(this.state.counter>59)
                {
                    this.setState({minute:this.state.minute +1,counter:0})
                }

                if(this.state.minute>59)
                {
                    this.setState({hours:this.state.hours +1,minute:0})
                }
                },10)
                this.setState({start:x})    
            
            },

         stopTimer : ()=>{
                clearInterval(this.state.start)
                
            },

            resetTimer:()=>{
                this.setState({counter:0,minute:0,hours:0});
                clearInterval(this.state.start)
            }
        }
       
    }
    
  

    render()
    {
        return(
        <div className="container">
            <h1>{this.state.hours}:{this.state.minute}:{this.state.counter}</h1>
            <button onClick={this.state.startTimer}>Start</button>
            <button onClick={this.state.stopTimer}>Stop</button>
            <button onClick={this.state.resetTimer}>Reset</button>


        </div>
        )
    }
 
}
export default StopWatch;
