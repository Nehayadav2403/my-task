import React from "react";
import calc from "./calc.json";



class Calculator extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state ={
            value:"",
            isOperatorClicked:false,
            opValue:"",
            operand:[],
            operator:[],

            add:(value,type)=>{
                this.setState({opValue:this.state.opValue +value})

                if(type === 'operator')
                {
                    console.log('operator',this.state.operand +value);
                    this.setState({
                        operator:[...this.state.operator,value],
                        operand:[...this.state.operand,this.state.opValue],
                        isOperatorClicked:true,
                        opValue:"",
                    });
                    
                }
                if(type === 'operand')
                    {
                        // console.log("opValue",this.state.opValue + value);
                        this.setState({
                            opValue:this.state.opValue +value,
                            isOperatorClicked:false,
                        });
                    }

                    if(type === 'clear')
                    {
                        this.setState({operand:[],operator:[],value:"",opValue:""});
                    }
                    if(type === 'equal')
                    {
                         this.setState({
                            operand:[...this.state.operand,this.state.opValue],
                        })
                    }
                    
            }
        

        }
    }
    render()
    {
        const {value} = this.state;
        return( 
                <div className="calc">
                <div className="text" 
                style={{          textAlign:"center",
                                  marginLeft:"110px",
                                  color:"midnightblue"
            
            
            }}>
                <h1>Calculator</h1> </div>
                <form>
                <div id="val">{value}</div>
         </form>
                <div className="box" 
                style={{        border:"1px solid ",
                                height:"375px",
                                marginLeft:"520px",
                                marginRight:"520px",
                                display:"flex",
                                flexWrap:"wrap",
                                flexDirection:"row",
                                background:"lightsalmon",
                            
                            
                            }}>
               
         
                <div className="cal" style={{border:"1px solid", height:"50px", width:"306px"}}></div>
          
                
                {calc.map((data,index)=>(
             <div 
                 key={index} style={{

                margin:"5px",
                border:"1px solid", 
                width:"60px",
                height:"32px",
                textAlign:"center",
                paddingTop:"10px"
                
                

               }}
            
                    onClick={()=>this.state.add(data.value,data.type)}
                    
                   >{data.value}</div>
                 )
         
         )}
         </div>
         </div>
         
        )
       
        
    }
}
export default Calculator;