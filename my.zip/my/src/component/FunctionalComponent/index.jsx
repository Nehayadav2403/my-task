import { Typography } from "@mui/material";
import { useState } from "react";
import { Button } from "@mui/material";

const FunctionalComponent = () => {
  const [counter, setCounter] = useState(0);
  return (
    <div>
      <Button variant="contained" onClick={() => setCounter(counter + 1)}>
        +
      </Button>
      <Typography variant="h2">{counter}</Typography>
      <Button variant="contained" onClick={() => setCounter(counter - 1)}>
        -
      </Button>
    </div>
  );
};
export default FunctionalComponent;
