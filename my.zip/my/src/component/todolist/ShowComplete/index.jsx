import { Typography } from "@mui/material";
import React from "react";

const ShowComplete =({data}) =>{
    return(
        <div>
         {data.map((listData,index)=>{
            if(listData.type === "complete")
            {
            return(
                    <div style={{
                        display:"flex",
                        alignItems:"center",
                    }} 
                    key ={index}
                    >

                    <Typography key={index} 
                                variant="body2"
                                fontWeight={"bold"}>
                     
                        {listData.name.charAt(0).toUpperCase() + listData.name.slice(1)}
                                
                    </Typography>
                                            
                    </div>
            )
            }
         })}
        
        
        </div>

    );
};
export default ShowComplete