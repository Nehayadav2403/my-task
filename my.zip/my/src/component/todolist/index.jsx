import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Tabs from "./Tab";
import ShowTodo from "./ShowTodo";
import ShowComplete from "./ShowComplete";
import ShowAll from "./ShowAll";
import NoDataFound from "./NoDataFound";

const Todo = () => {
  const [textField, setTextField] = useState("");
  const [todo, setTodo] = useState([]);
  const[activeTab,setActiveTab]=useState(1);
  const upDateCheck =(index,checked) =>{
    let tempData = todo;
    tempData[index].check = checked;
    setTodo(tempData);
  };

  const updateType = (index) =>{
    todo[index].type = "complete";
    setTodo([...todo]);
  };
  return (
    <div className="input-container" style={{ margin: "16px ",textAlign:"center" }}>
      <TextField
        id="outlined-basic"
        label="Add your task"
        variant="outlined"
        value={textField}
        onChange={(e) => setTextField(e.target.value)}
      />
      ,
      <Button
        variant="contained"
        style={{ padding: "15px", marginLeft: "8px" }}
        onClick={() => {
          setTodo([...todo, { name: textField, check: false, type: "todo" }]);

          setTextField("");
        }}
      >
        Add
      </Button>

     <Tabs changeTab={setActiveTab} active={activeTab}/>

     {activeTab === 1 ? (
      <div style={{margin:"45px",textAlign:"left"}}>
      {todo.length ? (
        <ShowTodo 
        data = {todo}
        upDateCheck = {upDateCheck}
        updateType = {updateType}
         />
      ):(
        <NoDataFound/>
      )}
      </div>
      
     ) : activeTab === 2 ? (
      <div style={{margin:"45px",textAlign:"center"}}>
      {todo.length ? (
        <ShowComplete 
        data = {todo}
        />
      ):(
        <NoDataFound/>
      
      )}
      </div>

     ) : activeTab === 3 ? (
      <div style={{margin:"45px",textAlign:"right"}}>
      {todo.length ? (
        <ShowAll 
        data  = {todo}
        />
      ):
        <NoDataFound />}
        </div>) : null}
      
   </div>
  );
};
export default Todo;
