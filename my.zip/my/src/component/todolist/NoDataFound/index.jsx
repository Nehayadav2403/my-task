import React from "react";

const NoDataFound =()=>{

    return (
        <div>No Data</div>
    )
}
export default NoDataFound